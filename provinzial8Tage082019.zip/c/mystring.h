/*
 * mystring-Funktionen
 * (co) Stockmayer
 * 29.08.2019
 */

#ifndef _MYSTRING_H_
#define _MYSTRING_H_

void printAscii(char* arr);		// char arr[]
int lenString(char* arr);
void stringKopie(char* von, char* nach);

#endif // _MYSTRING_H_
