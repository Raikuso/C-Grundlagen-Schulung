/*
 * bits-Beispiel
 * (co) Stockmayer
 * 26.08.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	int a = 21;
	int b = 25;

	cout << "und:    " << (a & b) << endl;
	cout << "oder:   " << (a | b) << endl;
	cout << "exoder: " << (a ^ b) << endl;
	cout << "rumdr.: " << (~a) << endl;
	cout << "links:  " << (a << 1) << endl;
	cout << "rechts: " << (a >> 1) << endl;

	return 0;
}
