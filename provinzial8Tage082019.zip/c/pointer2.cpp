/*
 * pointer-Wiederholung
 * (co) Stockmayer
 * 04.09.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	int var;
	int* p = &var;
	*p = 4711;
	cout << *p << " " << p << " " << var << endl;

	p = (int*)malloc(sizeof(int));
	if(p)
	{
		*p = 4711;
		cout << *p << " " << p << endl;
		free(p);
	}

	return 0;
}
