/*
 * Rechteck-Klasse
 * (co) Stockmayer
 * 30.08.2019
 */

#ifndef _RECHTECK_H_
#define _RECHTECK_H_

typedef
struct Rechteck
{
	int laenge;
	int breite;
} Rechteck;
void printRechteck(struct Rechteck r);
int flaecheRechteck(Rechteck r);
int umfangRechteck(struct Rechteck r);

#endif // _RECHTECK_H_
