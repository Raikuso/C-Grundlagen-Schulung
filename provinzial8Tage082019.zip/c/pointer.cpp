/*
 * pointer-Beispiel
 * (co) Stockmayer
 * 02.09.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	int i;
	int j;
	int* pi;
	long l;
	long* pl;

	pi = &i;
	*pi = 42;
	pl = &l;
	*pl = 2435234234234L;

	cout << i << " " << *pi << " " << pi << " " << &j << endl;
	cout << l << " " << *pl << " " << pl << " " << endl;

	return 0;
}
