/*
 * Summe aller Zahlen mit for
 * (co) Stockmayer
 * 27.08.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	int z;
	const int MAX = 100000;
	long long summe;

	for(z = 1, summe = 0LL; z <= MAX; ++z)
	{
		//cout << z << " ";
		summe += z;			// summe = summe + z;
		//++z;
	}
	cout << endl << summe << endl;

	return 0;
}
