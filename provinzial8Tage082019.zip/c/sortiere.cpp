/*
 * sortiere-Funktionen
 * (co) Stockmayer
 * 28.08.2019
 */
#include <iostream>
using namespace std;
#include "sortiere.h"

/*
 * füllt ein Array mit Ganzzahlen auf
 * @param arr das Array
 * @param len Anzahl der Arrayelemente
 */
void fuelleArray(int arr[], int len)
{
	int z;
	for(z = 0; z < len; ++z)
	{
		cout << "bitte " << (z+1) << ". Zahl: ";
		cin >> arr[z];
	}
}

/*
 * printet ein Array mit Ganzzahlen
 * @param arr das Array
 * @param len Anzahl der Arrayelemente
 */
void printArray(int arr[], int len)
{
	int z;
	for(z = 0; z < len; ++z)
	{
		cout << (z+1) << ". Zahl: " << arr[z] << endl;
	}
}

/*
 * sortiert ein Array mit Ganzzahlen (mod. Bubble-Sort)
 * @param arr das Array
 * @param len Anzahl der Arrayelemente
 */
void sortArray(int arr[], int len)
{
	int i;
	int j;
	int help;

	for(i = 0; i < len-1; ++i)
	{
		for(j = i+1; j < len; ++j)
		{
			if(arr[j] < arr[i])
			{
				help = arr[j];
				arr[j] = arr[i];
				arr[i] = help;
			}
		}
	}
}













