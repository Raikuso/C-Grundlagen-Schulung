/*
 * versicherungMain
 * (co) Stockmayer
 * 30.08.2019
 */

#include <iostream>
#include <string>
using namespace std;
#include "versicherung.h"

int main()
{
	VersicherungsVertrag v1 = createVersicherung(); 
	VersicherungsVertrag v2 = { "Stockmayer", "30.08.1953", "V-1234-5678-9", 'K',
				    "DE71532900000031365414", 100000., 123.45 };
	VersicherungsVertrag v3 = { "Müller", "30.08.1999", "V-1234-5678-1", 'H',
				    "DE71532900000031365414", 10000000., 123.45 };
	VersicherungsVertrag arr[3];
	char nummer[MAXNUM+1];

	arr[0] = v1;
	arr[1] = v2;
	arr[2] = v3;

	printAlleVersicherungen(arr, 3);
	erhoeheBeitrag(arr, 3, 10.);
	printAlleVersicherungen(arr, 3);
	cout << "Bitte Versicherungsnummer: ";
	cin >> nummer;
	VersicherungsVertrag* p = sucheVersicherung(arr, 3, nummer);
	if(p)				// != nullptr
	{
		printVersicherung(p);
	}
	else
	{
		cerr << "kein Vertrag gefunden: " << nummer << endl;
	}
	cout << "ok: " << saveAlleVersicherungen(arr, 3, "versicherungen.csv") << endl;

	return 0;
}
