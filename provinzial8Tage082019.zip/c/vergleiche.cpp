/*
 * vergleiche-Beispiel
 * (co) Stockmayer
 * 26.08.2019
 */

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
	double zahl1;
	double zahl2;
	
	cout << "bitte eine 1. Zahl: ";
	cin >> zahl1;
	cout << "bitte eine 2. Zahl: ";
	cin >> zahl2;
	cout << "eingegeben wurde: " << zahl1 << endl;
	cout << "eingegeben wurde: " << zahl2 << endl;

	cout << boolalpha;
	cout << "Vergleich auf größer: " << (zahl1 > zahl2) << endl;
	cout << "Vergleich auf kleiner als 5: " << (zahl1 < 5) << endl;
	cout << "Vergleich auf kleiner als 5 und größer als 2: " 
		<< (zahl1 < 5 && zahl2 > 2) << endl;
	
	return 0;
}
