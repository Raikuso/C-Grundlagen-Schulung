/*
 * max1-Beispiel
 * (co) Stockmayer
 * 26.08.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	double zahl1;
	double zahl2;
	cout << "bitte eine 1. Zahl: ";
	cin >> zahl1;
	cout << "bitte eine 2. Zahl: ";
	cin >> zahl2;
	cout << "eingegeben wurde: " << zahl1 << endl;
	cout << "eingegeben wurde: " << zahl2 << endl;

	if(zahl1 > zahl2)
	{
		cout << zahl1 << " ist größer!" << endl;
	}
	else if(zahl1 == zahl2)
	{
		cout << "zahlen sind gleich!" << endl;
	}
	else
	{
		cout << zahl2 << " ist größer!" << endl;
	}

	return 0;
}
