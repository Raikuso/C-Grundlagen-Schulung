/*
 * versicherung-Beispiel
 * (co) Stockmayer
 * 30.08.2019
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;
#include "versicherung.h"

/*
 * anlegen neuer Versicherungsvertrag
 * @return der neue Versicherungsvertrag
 */
VersicherungsVertrag createVersicherung()
{
	VersicherungsVertrag v;

	cout << "Name:                      ";
	cin.getline(v.name, MAXNAME);

	cout << "Geburtsdatum (tt.mm.yyyy): ";
	cin >> v.geburt;

	cout << "Versicherungsnummer:       ";
	cin >> v.versNr;

	cout << "Typ (k,h):                 ";
	cin >> v.typ;

	do
        {
		cout << "IBAN (22Stellen):          ";
                cin >> v.iban;
        }
        while(strlen(v.iban) != MAXIBAN);

	cout << "Versicherungssumme (in €): ";
	cin >> v.versSumme;

	v.beitrag = v.versSumme / 1000.;

	return v;
}

/*
 * such Vertrag anhand der Versicherungsnummer
 * @param arr Array mit Versicherungsverträgen
 * @param len Anzahl der Verträge
 * @param vnummer Versicherungsnummer
 * @return der gefundene Vertrag
 */
VersicherungsVertrag* sucheVersicherung(VersicherungsVertrag arr[], int len, char vnummer[])
{
	int z;
	for(z = 0; z < len; ++z)
	{
		if(strcmp(vnummer, arr[z].versNr) == 0)
		{
			return arr+z;       //&arr[z];
		}
	}
	return nullptr;
}

/*
 * erhöht Beitrag aller Versicherungsverträge um einen bestimmten Prozentsatz
 * @param arr Array mit Versicherungsverträgen
 * @param len Anzahl der Verträge
 * @param hoehe prozentuelle Erhöhung
 */
void erhoeheBeitrag(VersicherungsVertrag arr[], int len, double hoehe)
{
	int z;
	for(z = 0; z < len; ++z)
	{
		//arr[z].beitrag = arr[z].beitrag * ( 1 + hoehe/100.);
		arr[z].beitrag *=  1 + hoehe/100.;
	}
}

/*
 * Speichern aller Versicherungsverträge als CSV-Datei
 * @param arr Array mit Versicherungsverträgen
 * @param len Anzahl der Verträge
 * @param datei Dateiname
 */
int saveAlleVersicherungen(VersicherungsVertrag arr[], int len, char* datei)
{
	int z;
	ofstream file(datei);
	int erg = 0;

	for(z = 0; z < len; ++z)
	{
		file << arr[z].name << ";" << arr[z].geburt << ";" << arr[z].versNr << ";";
		file << arr[z].typ << ";" << arr[z].iban << ";" << arr[z].versSumme << ";";
		file << arr[z].beitrag;
		file << endl;
	}
	erg = file.good();
	file.close();
	return erg;
}

/*
 * Ausgabe aller Versicherungsverträge
 * @param arr Array mit Versicherungsverträgen
 * @param len Anzahl der Verträge
 */
void printAlleVersicherungen(VersicherungsVertrag arr[], int len)
{
	int z;
	for(z = 0; z < len; ++z)
	{
		printVersicherung(&arr[z]);
		cout << endl;
	}
}

/*
 * Ausgabe Versicherungsvertrag
 * @param v VersicherungsVertrag
 */
void printVersicherung(VersicherungsVertrag* pv)
{
	cout << showpoint << fixed << setprecision(2);
	cout << "Versicherungsvertrag: " << endl;
	cout << "Versicherungsnummer:  " << (*pv).versNr << endl;
	cout << "Name:                 " << pv->name << endl;
	cout << "Geburtsdatum:         " << pv->geburt << endl;
	switch(pv->typ)
	{
		case 'K':
		case 'k':
			cout << "Versicherungstyp:     " << "KFZ" << endl;
			break;
		case 'H':
		case 'h':
			cout << "Versicherungstyp:     " << "Haus" << endl;
			break;
		default:
			cout << "Versicherungstyp:     " << "unbestimmt" << endl;
			break;
	}
	cout << "IBAN:                 " << pv->iban << endl;
	cout << "Versicherungssumme:   " << pv->versSumme << endl;
	cout << "Jahresbeitrag:        " << pv->beitrag << endl;
}
