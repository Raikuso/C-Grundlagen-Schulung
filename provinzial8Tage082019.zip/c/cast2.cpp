/*
 * cast2-Beispiel
 * (co) Stockmayer
 * 04.09.2019
 */

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
	double z = (int)10.9999;		(double)(int)10.9999 -> (double)10 -> 10.000
	cout << showpoint << z << endl;
	return 0;
}
