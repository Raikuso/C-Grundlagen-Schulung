/*
 * malloc-Beispiel
 * (co) Stockmayer
 * 02.09.2019
 */

#include <iostream>
#include <cstdlib>
using namespace std;

int main()
{
	int anz;
	double* p;

	cout << "wieviele double's: ";
	cin >> anz;

	p = (double*)malloc(anz * sizeof(double));
	if(p)		// p != nullptr oder p != NULL
	{
		*p = 234.56;		// p[0] = 234.56;
		*(p+anz-1) = 567.89;	// p[anz-1] = 567.89;
		cout << *p << " " << *(p+anz-1) << endl;
		free(p);
	}
	else
	{
		cerr << "kein Speicher verfügbar!" << endl;
	}


	return 0;
}
