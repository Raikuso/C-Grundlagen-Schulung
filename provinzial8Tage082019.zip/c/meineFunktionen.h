/*
 * MeineFunktionen: Deklarationen
 * (co) Stockmayer
 * 28.08.2019
 */
#ifndef MEINEFUNKTIONEN_H_
#define MEINEFUNKTIONEN_H_

double berechneBrutto(double netto, double steuer);
int myMax(int z1, int z2);
void print(double zahl);

const double PI = 3.141592653589793;
double berechneFlaeche(double r);
double berechneUmfang(double r);

int berechneSummeVielfache(int zahl, int max);

#endif /* MEINEFUNKTIONEN_H_ */
