#include <stdio.h>
#include "Filetest.c"
int main(void)
{
   druck();
   getchar();
   return 0;
}
