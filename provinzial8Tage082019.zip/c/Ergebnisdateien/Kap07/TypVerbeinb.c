#include <stdio.h>
   typedef struct tmodell
{
  char Marke[30];
  int farbe;
  float hoechstv;
  float hubraum;
}
tmodell;
int main(void)
{
  return 0;
}