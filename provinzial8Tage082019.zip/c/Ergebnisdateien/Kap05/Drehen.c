#include <stdio.h>
int main(void)
{
   int z1, z2, z3, z4, z5, z6, z7, z8, z9;
   char z;
   printf("Ihr Name (9 Buchstaben): ");
   z1 = getchar();
   z2 = getchar();
   z3 = getchar();
   z4 = getchar();
   z5 = getchar();
   z6 = getchar();
   z7 = getchar();
   z8 = getchar();
   z9 = getchar();
   putchar(z9);
   putchar(z8);
   putchar(z7);
   putchar(z6);
   putchar(z5);
   putchar(z4);
   putchar(z3);
   putchar(z2);
   putchar(z1);
   getchar();
   fflush(stdin);  /* Eingabepuffer loeschen */
   getchar();
   return 0;
}
