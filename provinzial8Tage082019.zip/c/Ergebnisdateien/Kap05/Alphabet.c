#include <stdio.h>
int ausgabe(int zaehler)
{
   putchar(zaehler);
   putchar(32);
   zaehler++;
   return zaehler;
}
int main(void)
{
   int zaehler = 65; 
   printf("DAS ALPHABET\n\n");
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   zaehler = ausgabe(zaehler);
   printf("\n");
   getchar();
   return 0;
}
