#include <stdio.h>
float z1, z2;
float add(void)
{
   return z1 + z2;
}
float sub(void)
{
   return z1 - z2;
}
float mul(void)
{
   return z1 * z2;
}
float div(void)
{
   return z1 / z2;
}
int main(void)
{
   printf("Taschenrechner...DEMO\n\n");
   printf("Bitte geben Sie zwei Zahlen ein!\n");
   printf("Zahl1: ");
   scanf("%f", &z1);
   printf("Zahl2: ");
   scanf("%f", &z2);
   printf("ERGEBNISSE\n\n");
   printf("Addition: %5.3f\n", add());
   printf("Subtraktion: %5.3f\n", sub());
   printf("Multiplikation: %5.3f\n", mul());
   printf("Division: %5.3f\n", div());
   getchar();   
   fflush(stdin);
   getchar();
   return 0;
}
