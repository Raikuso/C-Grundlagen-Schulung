/* Schauen Sie sich das Programm genau an */
#include <stdio.h>
void main(void)
{
  char *satz = "Das Zukuenftige ist viel zu unbestimmt,";
  char *zeiger = "um als praezise Handlungsmaxime zu dienen.";
  puts(satz);
  puts(zeiger);
  fflush(stdin);
  getchar();
}