#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	char *s1, *s2, *s3;
	//s1 = malloc(80 * sizeof(char));
	//s2 = malloc(80 * sizeof(char));
	//s3 = malloc(80 * sizeof(char));
	// Bei eventueller Fehlermeldung wegen Typinkompatibilit�t - cast erforderlich:   
	s1 = (char*)malloc(80 * sizeof(char));
	s2 = (char*)malloc(80 * sizeof(char));
	s3 = (char*)malloc(80 * sizeof(char));
	fgets(s1, 80, stdin);
	fgets(s2, 80, stdin);
	fgets(s3, 80, stdin);
	printf("\n\n\n\n");
	puts(s1);
	puts(s2);
	puts(s3);
	free(s1);
	free(s2);
	free(s3);
	getchar();
	return 0;
}
