/*
 * praecompiler2-Beispiel
 * (co) Stockmayer
 * 04.09.2019
 */

#include <iostream>
#include <string>
using namespace std;
#define XXX

#define wasichwill(a) ((a)*(a)*(a))

int main()
{
#ifdef XXX
	cout << "ein Text: " << wasichwill(10) << endl;
#endif	// XXX

	return 0;
}
