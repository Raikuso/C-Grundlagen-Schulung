/*
 * meineFMain-Beispiel
 * (co) Stockmayer
 * 28.08.2019
 */
#include <iostream>
using namespace std;
#include "meineFunktionen.h"

int main()
{
	print(123.456);
	cout << berechneBrutto(100., 19.) << endl;
	cout << "größte Zahl: " << myMax(20, 30) << endl;

	cout << "Fläche: " << berechneFlaeche(2.2) << endl;
	cout << "Umfang: " << berechneUmfang(2.2) << endl;

	cout << "Vielfaches: " << berechneSummeVielfache(3, 10) << endl;

	return 0;
}
