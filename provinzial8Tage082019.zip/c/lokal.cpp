/*
 * lokal-Beispiel
 * (co) Stockmayer
 * 28.08.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	while(1)
	{
		double x;		// ungünstig
	}

	return 0;
}
