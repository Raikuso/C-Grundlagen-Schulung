/*
 * listeMain: verkettete Liste
 * (co) Stockmayer
 * 03.09.2019
 */

#include <iostream>
#include <string>
using namespace std;
#include "liste.h"

int main()
{
	ListElement* root = nullptr;
	int zahl;

	while(cout << "bitte Zahl: ", cin >> zahl)
	{
		cout << "Zahl: " << zahl << endl;
		root = verkette(root, zahl);
	}
	ausgabe(root);
	freigabe(root);

	return 0;
}
