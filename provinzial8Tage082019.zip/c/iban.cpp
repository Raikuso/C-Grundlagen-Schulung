/*
 * IBAN einlesen und prüfen
 * (co) Stockmayer
 * 29.08.2019
 */

#include <iostream>
#include <cstring>
using namespace std;

const int LEN = 22;

int main()
{
	char iban[LEN+1];

	do
	{
		cout << "Bitte 22stellige IBAN: ";
		cin >> iban;
	}
	while(strlen(iban) != LEN);
	cout << "IBAN: " << iban << endl;

	return 0;
}
