/*
 * plusplus-Beispiel
 * (co) Stockmayer
 * 26.08.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	int x = 9;
	int y = ++x;

	cout << x << " " << y << endl;

	x = 9;
	y = x++;
	cout << x << " " << y << endl;

	return 0;
}
