/*
 * Variablen-Beispiel
 * (co) Stockmayer
 * 26.08.2019
 */

#include <iostream>
#include <string>
#include <cstring>
using namespace std;

int main()
{
	int var1 = 10;							// eine Ganzzahl
	const long var2 = 23123123123L;
	long long var3 = 23123123345345345LL;
	double var4 = 3.14;
	long double var5 = 3.141234567890123456789;
	char var6 = 97; // 'a';
	string var7 = "abc";
	char var8[10] = "abc";

	//var2 = 456L;					// geht nicht, ist konstant

	cout << "Hallo" << endl;
	cout << "der Inhalt der Variablen var1 ist: " << var1 << endl;
	cout << "int hat Bytes: " << sizeof(int) << endl;

	cout << "der Inhalt der Variablen var2 ist: " << var2 << endl;
	cout << "long hat Bytes: " << sizeof(long) << endl;

	cout << "der Inhalt der Variablen var3 ist: " << var3 << endl;
	cout << "long long hat Bytes: " << sizeof(long long) << endl;

	cout << "der Inhalt der Variablen var4 ist: " << var4 << endl;
	cout << "double hat Bytes: " << sizeof(double) << endl;

	cout << "der Inhalt der Variablen var5 ist: " << var5 << endl;
	cout << "long double hat Bytes: " << sizeof(long double) << endl;

	cout << "der Inhalt der Variablen var6 ist: " << var6 << endl;
	cout << "der Inhalt der Variablen var6 ist: " << (int)var6 << endl;
	cout << "char hat Bytes: " << sizeof(char) << endl;

	cout << "der Inhalt der Variablen var7 ist: " << var7 << endl;
	cout << "var7 hat Bytes: " << var7.length() << endl;

	cout << "der Inhalt der Variablen var8 ist: " << var8 << endl;
	cout << "var8 hat Bytes: " << sizeof(var8) << endl;
	cout << "var8 hat Länge: " << strlen(var8) << endl;

	return 0;
}
