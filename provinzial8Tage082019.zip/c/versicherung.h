/*
 * Versicherung-Klasse
 * (co) Stockmayer
 * 30.08.2019
 */

#ifndef _VERSICHERUNG_H_
#define _VERSICHERUNG_H_

#define MAXNAME 100
#define MAXDATUM 10
#define MAXNUM 100
#define MAXIBAN 22

typedef
struct VersicherungsVertrag
{
	char name[MAXNAME+1];
	char geburt[MAXDATUM+1];
	char versNr[MAXNUM+1];
	char typ;
	char iban[MAXIBAN+1];
	double versSumme;
	double beitrag;
} VersicherungsVertrag;

void printVersicherung(VersicherungsVertrag* v);
VersicherungsVertrag createVersicherung();
void printAlleVersicherungen(VersicherungsVertrag arr[], int len);
int saveAlleVersicherungen(VersicherungsVertrag* arr, int len, char* datei);
void erhoeheBeitrag(VersicherungsVertrag arr[], int len, double hoehe);
VersicherungsVertrag* sucheVersicherung(VersicherungsVertrag arr[], int len, char vnummer[]);

#endif // _VERSICHERUNG_H_




