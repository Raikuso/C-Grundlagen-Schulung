/*
 * Zeigerquiz
 */
#include <iostream>
using namespace std;

int main(void)
{
	const char *c[]    = { "ENTER", "NEW", "POINT", "FIRST" };
	const char **cp[]  = { c+3, c+2, c+1, c };
	const char ***cpp  = cp;

	cout << **++cpp;
	cout << *--*++cpp+3;
	cout << *cpp[-2]+3;
	cout << cpp[-1][-1]+1 << endl;

	return 0;
}
