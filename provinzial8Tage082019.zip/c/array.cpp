/*
 * array-Beispiel
 * (co) Stockmayer
 * 28.08.2019
 */

#include <iostream>
#include <string>
using namespace std;
#include "sortiere.h"

const int MAX = 10;

int main()
{
	int arr[MAX];

	fuelleArray(arr, MAX);
	sortArray(arr, MAX);
	printArray(arr, MAX);


	return 0;
}
