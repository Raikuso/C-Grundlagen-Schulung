/*
 * pointerarray-Beispiel
 * (co) Stockmayer
 * 03.09.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	int a1[2];
	int a2;
	int a3[3];
	int* arr[3] = { a1, &a2, a3 };
	int** p = arr;

	**p = 10;		p[0][0] = 10;	*p[0] = 10;	(*p)[0] = 10;
	*(*p+1) = 20;		p[0][1] = 20;	*(p[0]+1) = 20;	(*p)[1] = 20;
	**(p+1) = 30;   	p[1][0] = 30;   *p[1] = 30;	(*(p+1))[0] = 30;
	**(p+2) = 40;		p[2][0] = 40;	*p[2] = 40;	(*(p+2))[0] = 40;
	*(*(p+2)+1) = 50;	p[2][1] = 50;	*(p[2]+1) = 50;	(*(p+2))[1] = 50;
	*(*(p+2)+2) = 60;	p[2][2] = 60;	*(p[2]+2) = 60;	(*(p+2))[2] = 60;

	cout << *(*(p+2)+1) << endl;
	cout << a1[1] << endl;

	return 0;
}
