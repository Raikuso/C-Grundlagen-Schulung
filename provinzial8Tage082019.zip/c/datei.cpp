/*
 * datei-Beispiel
 * (co) Stockmayer
 * 04.09.2019
 */

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
	ofstream file("output.txt");
	file << "eine erste Zeile" << endl;
	file << "und noch ne Zeile" << endl;
	file << "oder ne Zahl: " << 12345 << endl;
	if(file.good())
	{
		cout << "alles gut!" << endl;
	}
	file.close();

	return 0;
}
