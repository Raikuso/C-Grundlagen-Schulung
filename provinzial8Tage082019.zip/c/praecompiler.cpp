/*
 * praecompiler-Beispiel
 * (co) Stockmayer
 * 29.08.2019
 */

#include <iostream>
using namespace std;

#define T "ein Text"
#define MAX 100
#define BEGIN {
#define END ;}
#define NL cout << endl
#define POW(x) ((x)*(x))
#define DEBUG

int main()
BEGIN
	int var = 5;
	NL;
	cout << T << " " << MAX << endl;
	NL;
	cout << "im Quadrat: " << POW(4.4) << endl;
	cout << "im Quadrat: " << POW(var+2) << endl;
#ifdef DEBUG
	cout << "im Quadrat: " << ((var+2) * (var+2)) << endl;
	cout << "im Quadrat: " << POW(var) << endl;
	cout << "im Quadrat: " << POW(++var) << endl;			// Vorsicht
	cout << "im Quadrat: " << ((++var)*(++var)) << endl;		// Vorsicht
#endif
	NL;

	return 0
END
