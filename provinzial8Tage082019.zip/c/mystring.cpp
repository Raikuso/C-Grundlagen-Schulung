/*
 * mystring-Beispiel
 * (co) Stockmayer
 * 29.08.2019
 */
#include <iostream>
using namespace std;
#include "mystring.h"

/*
 * gibt String zeichenweise mit ASCII-Code aus (inkl. \0)
 * @param arr der String
 */
void printAscii(char* arr)		// char arr[]
{
	//int z = 0;
	//do
	//{
	//	cout << arr[z] << ": " << (int)arr[z] << endl;
	//} 
	//while(arr[z++] != '\0');
	do
	{
		cout << *arr << ": " << (int)*arr << endl;
	} 
	while(*arr++ != '\0');
}

/*
 * berechnet Länge eines Strings
 * @param arr der String
 */
int lenString(char* arr)		// char arr[]
{
	char* first = arr;
	while(*arr++) ;			// != '\0'	{ }
	return arr - first - 1;
}

/*
 * kopiert String
 * @param von Quellstring
 * @param nach Zielstring
 */
void stringKopie(char* von, char* nach)
{
	// 1. Lösung:
	//int z = 0;
	//while(von[z] != '\0')
	//{
	//	nach[z] = von[z];
	//	++z;
	//}
	//nach[z] = '\0';
	// 2. Lösung:
	//while(*von != '\0')
	//{
	//	*nach++ = *von++;
	//}
	//*nach = '\0';
	// 3. Lösung:
	while(*nach++ = *von++);
}









