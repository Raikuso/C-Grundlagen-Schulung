/*
 * meineFunktionen
 * (co) Stockmayer
 * 28.08.2019
 */
#include <iostream>
#include <cmath>
using namespace std;
#include "meineFunktionen.h"

/*
 * berechnet Summe der Vielfachen
 * 3 + 6 + 9 bei einem max von 10
 * @param zahl Vielfache dieser Zahl
 * @param max bis Vielfaches dies erreicht
 * @return Summe
 */
int berechneSummeVielfache(int zahl, int max)
{
	int summe = 0;
	int viel = zahl;
	while(viel <= max)
	{
		summe += viel;
		viel += zahl;
	}
	return summe;
}

/*
 * berechnet Fläche
 * braucht PI
 * @param r Radius des Kreises
 * @return Flächeninhalt
 */
double berechneFlaeche(double r)
{
	return PI * pow(r, 2.);		// r * r
}

/*
 * berechnet Umfang
 * braucht PI
 * @param r Radius des Kreises
 * @return Kreisumfang
 */
double berechneUmfang(double r)
{
	return PI * 2. * r;
}

/*
 * berechnet Bruttobetrag
 * @param netto Nettobetrag
 * @param steuer Steuersatz
 * @return Bruttobetrag
 */
double berechneBrutto(double netto, double steuer)
{
	return netto * ( 1. + steuer/100.);
}

/*
 * nimmt die größte
 * @param z1 1.Zahl
 * @param z2 2.Zahl
 * @return die größte
 */
int myMax(int z1, int z2)
{
//	if(z1 > z2)
//	{
//		return z1;
//	}
//	else
//	{
//		return z2;
//	}

	return z1 > z2 ? z1 : z2;
}

/*
 * gibt Parameter aus
 */
void print(double zahl)
{
	cout << "Zahl: " << zahl << endl;
}
