/*
 * cast-Beispiel
 * (co) Stockmayer
 * 26.08.2019
 */

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	double zahl = 10.2;
	double erg = (int)(zahl + 0.5);
	cout << showpoint << erg << endl;

	return 0;
}
