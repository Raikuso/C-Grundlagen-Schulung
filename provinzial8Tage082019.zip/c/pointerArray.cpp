/*
 * pointerArray-Beispiel
 * (co) Stockmayer
 * 02.09.2019
 */

#include <iostream>
#include <string>
using namespace std;

#define MAX 10

int main()
{
	short arr[MAX] = { 2,6,34,1,4,6,9,5,-1,333 };
	short* p = arr;
	int z;
	int sum = 0;
	int max = 0;

	for(z = 0; z < MAX; ++z)
	{
		cout << p << ": " << *p <<  endl;
		if(*p > max)
		{
			max = *p;
		}
		sum += *p++;
		//++p;
	}
	cout << "Durchschnitt: " << sum/MAX << endl;
	cout << "MaxZahl:      " << max << endl;

	return 0;
}
