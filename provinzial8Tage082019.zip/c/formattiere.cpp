/*
 * formattiere-Beispiel
 * (co) Stockmayer
 * 04.09.2019
 */

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

int main()
{
	cout << fixed << setprecision(2) << ":" << setw(30) << 12345.45678 << ":" << endl;
	return 0;
}
