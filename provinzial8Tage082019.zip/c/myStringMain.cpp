/*
 * String-Experimente
 * (co) Stockmayer
 * 29.08.2019
 */

#include <iostream>
#include <cstring>
using namespace std;
#include "mystring.h"

const int MAX = 100;

int main()
{
	char arr[MAX] = "abcdefghijk";
	char arr2[MAX];

	//cin.getline(arr, MAX);	// ne Zeile inkl. Blanks und TABs einlesen

	cout << arr << endl;
	printAscii(arr);
	cout << "Länge: " << lenString(arr) << endl;
	cout << "Länge: " << strlen(arr) << endl;
	//stringKopie(arr, arr2);
	strncpy(arr2, arr, MAX);		// arr2 = arr
	cout << "Kopie: " << arr2 << endl;
	strcat(arr, "xyz");
	cout << "Verlängert: " << arr << endl;

	if(strncmp(arr, arr2, 10) == 0)
	{
		cout << "Strings sind gleich!" << endl;
	}
	else
	{
		cout << "Strings sind nicht gleich!" << endl;
	}

	if(strstr(arr, "efg"))
	{
		cout << "efg ist drin!" << endl;
	}
	else
	{
		cout << "efg ist nicht drin!" << endl;
	}

	return 0;
}
