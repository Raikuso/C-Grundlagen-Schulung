/*
 * Noten als Text
 * (co) Stockmayer
 * 27.08.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	int note;
	string ntext;

	cout << "Welche Note: ";
	cin >> note;
	switch(note)
	{
		case 1:  ntext = "sehr gut"; break;
		case 2:  ntext = "gut"; break;
		case 3:  ntext = "befriedigend"; break;
		case 4:  ntext = "ausreichend"; break;
		case 5:  ntext = "mangelhaft"; break;
		case 6:  ntext = "ungenügend"; break;
		default: ntext = "keine Note!"; break;
	}
	cout << ntext << endl;

	return 0;
}
