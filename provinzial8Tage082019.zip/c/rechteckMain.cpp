/*
 * Rechteck
 * (co) Stockmayer
 * 30.08.2019
 */

#include <iostream>
#include <string>
using namespace std;
#include "rechteck.h"

int main()
{
	Rechteck r1 = { 100, 50 };		// struct Rechteck
	printRechteck(r1);
	cout << "Fläche: " << flaecheRechteck(r1) << endl;
	cout << "Umfang: " << umfangRechteck(r1) << endl;
	return 0;
}
