/*
 * schleifen-Beispiel
 * (co) Stockmayer
 * 04.09.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	int z = 1;

	while(z <= 10)
	{
		cout << z << " ";
		++z;
	}
	cout << endl;

	z = 1;
	do
	{
		cout << z << " ";
		++z;
	} while(z <= 10);
	cout << endl;

	for(z = 1; z <= 10; ++z)
	{
		cout << z << " ";
	}
	cout << endl;


	return 0;
}
