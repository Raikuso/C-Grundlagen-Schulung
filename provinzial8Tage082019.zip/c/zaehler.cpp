/*
 * Summe aller Zahlen
 * (co) Stockmayer
 * 27.08.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	int z = 1;
	const int MAX = 100000;
	long long summe = 0LL;

	while(z <= MAX)
	{
		//cout << z << " ";
		summe += z++;			// summe = summe + z;
		//++z;
	}
	cout << endl << summe << endl;

	return 0;
}
