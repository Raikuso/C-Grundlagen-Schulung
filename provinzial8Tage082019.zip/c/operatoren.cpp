/*
 * operatoren-Beispiel
 * (co) Stockmayer
 * 26.08.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	double zahl1;
	double zahl2;
	double erg;
	cout << "bitte eine 1. Zahl (Brutto): ";
	cin >> zahl1;
	cout << "bitte eine 2. Zahl (MWSt.Satz): ";
	cin >> zahl2;
	cout << "eingegeben wurde: " << zahl1 << endl;
	cout << "eingegeben wurde: " << zahl2 << endl;

	erg = zahl1 / ( 1 + zahl2 / 100 );

	cout << "Netto: " << erg << endl;
	
	return 0;
}
