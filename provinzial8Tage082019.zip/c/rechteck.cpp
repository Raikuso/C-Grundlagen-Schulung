/*
 * rechteck-Funktionen
 * (co) Stockmayer
 * 30.08.2019
 */

#include <iostream>
#include <string>
using namespace std;
#include "rechteck.h"

/*
 * gibt Länge und Höhe eines Rechtecks aus
 * @param r ein Rechteck
 */
void printRechteck(struct Rechteck r)
{
	cout << "ein Rechteck:" << endl;
	cout << "Länge:   " << r.laenge << endl;
	cout << "Breite:  " << r.breite << endl;
}

/*
 * berechnet Fläche eines Rechtecks
 * @param r ein Rechteck
 * @return Fläche
 */
int flaecheRechteck(Rechteck r)
{
	return r.laenge * r.breite;
}

/*
 * berechnet Umfang eines Rechtecks
 * @param r ein Rechteck
 * @return Umfang
 */
int umfangRechteck(struct Rechteck r)
{
	return 2*r.laenge + 2*r.breite;
}
