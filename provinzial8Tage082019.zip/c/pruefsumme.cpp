/*
 * pruefsumme-Beispiel
 * (co) Stockmayer
 * 27.08.2019
 */

#include <iostream>
#include <cstring>
using namespace std;

int main()
{
	char arr[27] = "1234767890123456789012345";
	unsigned int z;
	int faktor = 2;
	int summe = 0;
	int len = strlen(arr);

	cout << arr[0] << endl;
	cout << len << endl;

	for(z = 0; z < len; ++z)
	{
		cout << arr[z] << ": " << (int)arr[z] << ": " << (arr[z]-48)<< endl;
		summe = summe + (arr[z]-48)*faktor;
		++faktor;
	}
	cout << "Summe: " << summe << endl;
	cout << "Prüf:  " << (summe % 11) << endl;
	arr[len] = summe % 11 + 48;
	arr[len+1] = '\0';
	cout << arr << endl;


	return 0;
}
