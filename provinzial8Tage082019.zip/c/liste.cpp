/*
 * liste-Beispiel
 * (co) Stockmayer
 * 03.09.2019
 */

#include <iostream>
#include <cstdlib>
using namespace std;
#include "liste.h"

/*
 * Speicher freigeben
 * @param r Liste
 */
void freigabe(ListElement* r)
{
	if(r != nullptr)
	{
		freigabe(r->next);
		free(r);
	}
}

/*
 * verkettet ein Element am ENde der Liste
 * @param r Liste
 * @param z Zahl
 * @return das neue Element
 */
ListElement* verkette(ListElement* r, int z)
{
	if(r == nullptr)
	{
		ListElement* p = (ListElement*)malloc(sizeof(ListElement));
		if(p == nullptr)
		{
			cerr << "kein Speicher!" << endl;
			return nullptr;
		}
		p->value = z;
		p->next = nullptr;
		return p;
	}
	else if(r->value > z)
	{
		ListElement* p = (ListElement*)malloc(sizeof(ListElement));
		if(p == nullptr)
		{
			cerr << "kein Speicher!" << endl;
			return nullptr;
		}
		p->value = z;
		p->next = r;
		return p;
	}
	else
	{
		r->next = verkette(r->next, z);
		return r;
	}
}

/*
 * gibt alle Listenelemente aus
 * @param r Liste
 */
void ausgabe(ListElement* r)
{
	if(r != nullptr)
	{
		cout << r->value << endl;
		cout << r << endl;
		ausgabe(r->next);
	}
}
