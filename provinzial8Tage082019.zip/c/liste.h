/*
 * Liste-Klasse
 * (co) Stockmayer
 * 03.09.2019
 */

#ifndef _LISTE_H_
#define _LISTE_H_

typedef
struct ListElement
{
	int value;
	struct ListElement* next;
} ListElement;

ListElement* verkette(ListElement* r, int z);
void ausgabe(ListElement* r);
void freigabe(ListElement* r);

#endif // _LISTE_H_
