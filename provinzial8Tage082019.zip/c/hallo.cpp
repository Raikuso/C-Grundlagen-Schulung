/*
 * Hallo-Beispiel
 * (co) Stockmayer
 * 26.08.2019
 */

#include <iostream>
using namespace std;

int main()
{
	cout << "Hallo" << endl;

	return 0;
}
