/*
 * Sortiere-Beispiel
 * (co) Stockmayer
 * 28.08.2019
 */

#ifndef _SORTIERE_H_
#define _SORTIERE_H_

void fuelleArray(int arr[], int len);
void printArray(int arr[], int len);
void sortArray(int arr[], int len);

#endif // _SORTIERE_H_
