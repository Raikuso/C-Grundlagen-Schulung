void druck(void)
{
  printf("DIESE ANZEIGE STAMMT AUS EINER ANDEREN DATEI\n");
  return;
}
 
