/*
 * Körner auf Schach-Brett
 * (co) Stockmayer
 * 27.08.2019
 */

#include <iostream>
#include <string>
using namespace std;

int main()
{
	const int ANZ = 64;
	int z;
	unsigned long long korn;
	unsigned long long summe;

	for(z = 1, korn = 1, summe = 0; z <= ANZ; ++z)
	{
		summe = summe + korn;		// summe += korn;
		cout << z << ". Feld: " << korn << ", Summe = " << summe << endl;
		korn = korn * 2;		// korn *= 2;
	}
	cout << "in Tonnen:     " << (summe * 0.01 / 1000 / 1000) << endl;
	cout << "in Güterwagen: " << (summe * 0.01 / 1000 / 1000 / 1000) << endl;
	cout << "in Zügen:      " << (summe * 0.01 / 1000 / 1000 / 1000 / 100) << endl;
	cout << "in Tagen:      " << (summe * 0.01 / 1000 / 1000 / 1000 / 100 / 48) << endl;
	cout << "in Jahren:     " << (summe * 0.01 / 1000 / 1000 / 1000 / 100 / 48 / 365) << endl;


	return 0;
}
