#include <stdio.h>
#define f int
#define v (void)printf(
#define x ),exit(1);
#define y ){if(n)c=z(n,u),u=n,n=c;o[i]=n?'0'+(1&*n):'0';}
#define z(a,b) (f*)(~1&*a^(f)b)
#define k(l) if(!(l=(f*)malloc(sizeof(l))))v 23+m x if(1&(f)l)v 39+m x*l=
r(p,q,d)f*p,*q;{char o[81];f*n=p,i=39,*c,*u=d?q:z(p,q);o[40]='0'+(1&*p);
for(;i>=0;i--y u=d?z(p,q):q;n=p;for(i=41;i<79;i++y o[i++]='\r';o[i++]=0;
v o);(void)fflush(stdout);sleep(1);}
main(a,c)char**c;{char*u,*malloc(),*m=
"Usage: black [string]\n\0No more memory\n\0Unusable memory alignment\n\0jt,s@m@ (beleY%XX&Yz {z&z}i|R(|)*((.)i)hiniFiGJ%FG.JJgJ: ;;&;z {z&z}-RS/ROiOV OP+PsaPh+ijainnjmamfmfAlnnnnphppopv%vvgv.aABiB1/BVP11/1.%..&.OhrR-WV V1#1VP1CcC0R\
\n\n'CVP0\n!\n\n'\nEaEEnEamat!akckk'kwaww'wz,zzozEit +",
*n=m;f*q,*p=0,*g,b=3,d;
if(a>2)v m x n=a>1?c[1]:n;
/*v"\t\t\t\t\tV\n");*/
k(q)0;u=n;a=~1&'j';
while(a!='x'){
	/*r(q,p,b);*/
	for(;;u+=3){
		u= *u?u:n;
		if((~1&*u)==a&&(1&*q)<<1==(2&u[2]))break;
	}
	a=~1&u[1];
	d=(8&u[2])>>3;
	if(16&u[2])putchar(u[3]);
	if(4&u[2])*q|=1;else*q&=~1;
	if(b==d)g=p;else{
		g=z(q,p);
		if(!g){k(g)(f)q;*q^=(f)g;}
	}
	p=q;q=g;b=1-d;
}
/*r(q,p,b);v"\n");*/exit(0);
}
