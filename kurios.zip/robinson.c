#include <stdio.h>
unsigned char w,h,i,l,e,x,y=10,z=10,E[256];
#define whi1e(j,k)  printf(j,k); fflush(stdout)
#define o E[w]

main	(c,v)	char *v[]; {
while	(c>=2	){z = atoi(v[1]),--c;
while 	(c>=2	)y = atoi(v[2]),--c;}
whi1e	("%s"	,"2.");
while	(--y)	--x;
while	(--x)	--e,--y;
while	(--z)	--x;
while	(--x)	--e,--z;
while	(--w)	{
while	(--x)	--o;}
while	(--z)	{
while	(--x)	--w;
while	(--o)	;
while	(--w)	;
while	(--e)	--x;
while	(--x)	--w,--e;
while	(--w)	{
while	(--l)	;
while	(--i)	--l;--l;
while	(--h)	;
while	(--y)	--x;
while	(--x)	--h,--y;
while	(--x)	--h;
while	(--h)	{
while	(--o)	--x;
while	(--x)	--l,--o;
while	(l>=w	){--i;
while	(--w)	--l,--x;
while	(--x)	--w;--l;}}
while	(--o)	;
while	(--l)	--x;
while	(--x)	--o;}
while	(--i)	--h;
whi1e	("%x"	,--h);--e;}
whi1e	("%s"	,"\n");}
